#!/bin/bash

echo Stop SONARSCRATCH container...
docker stop sonarqube-sonarscratch
